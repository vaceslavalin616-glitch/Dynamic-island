package com.example.island

import android.app.PendingIntent
import android.graphics.drawable.Drawable

class IslandAction(val label: String, val run: () -> Unit)

enum class Kind { NOTIFICATION, CALL, MEDIA, TIMER, CHARGING }

data class IslandEvent(
    val kind: Kind = Kind.NOTIFICATION,
    val icon: Drawable? = null,
    val title: String = "",
    val text: String = "",
    val compactText: String = "",
    val intent: PendingIntent? = null,
    val actions: List<IslandAction> = emptyList(),
    val tintIcon: Boolean = true,
    val accent: Int = 0xFFFFFFFF.toInt(),
    val sticky: Boolean = false,
    val progress: Float = -1f,
    val key: String = ""
)

/** Шина между сервисами/приложением и островком (один процесс). */
object IslandBus {
    var onTransient: ((IslandEvent) -> Unit)? = null
    var onLive: ((Kind, IslandEvent?) -> Unit)? = null
    var onRemoved: ((String) -> Unit)? = null
    var onStartTimer: ((Int) -> Unit)? = null
    var onStopTimer: (() -> Unit)? = null
    var onRecalibrate: (() -> Unit)? = null

    fun post(e: IslandEvent) { onTransient?.invoke(e) }
    fun live(k: Kind, e: IslandEvent?) { onLive?.invoke(k, e) }
    fun removed(key: String) { onRemoved?.invoke(key) }
}
