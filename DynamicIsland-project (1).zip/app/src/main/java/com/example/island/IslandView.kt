package com.example.island

import android.animation.Animator
import android.animation.AnimatorListenerAdapter
import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Outline
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.text.TextUtils
import android.view.GestureDetector
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.ViewOutlineProvider
import android.view.animation.DecelerateInterpolator
import android.view.animation.LinearInterpolator
import android.view.animation.OvershootInterpolator
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import kotlin.math.abs
import kotlin.math.sin

private val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
private val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT

/** Кольцо-прогресс вокруг камеры (зарядка, таймер), как рамка вокруг отверстия. */
class RingView(ctx: Context) : View(ctx) {
    private val stroke = 2.5f * ctx.resources.displayMetrics.density
    private val p = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND; strokeWidth = stroke; color = Color.WHITE
    }
    private val track = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; strokeWidth = stroke; color = 0x33FFFFFF
    }
    private val r = RectF()

    var progress: Float = 0f
        set(v) { field = v.coerceIn(0f, 1f); invalidate() }
    var color: Int = Color.WHITE
        set(v) { field = v; p.color = v; invalidate() }

    override fun onDraw(c: Canvas) {
        val h = stroke / 2f + 1f
        r.set(h, h, width - h, height - h)
        c.drawArc(r, 0f, 360f, false, track)
        c.drawArc(r, -90f, 360f * progress, false, p)
    }
}

/** Анимированный эквалайзер для музыки. */
class EqView(ctx: Context) : View(ctx) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private var t = 0f
    var color: Int = Color.WHITE
    private val anim = ValueAnimator.ofFloat(0f, (2 * Math.PI).toFloat()).apply {
        duration = 1000L
        repeatCount = ValueAnimator.INFINITE
        interpolator = LinearInterpolator()
        addUpdateListener { t = it.animatedValue as Float; invalidate() }
    }

    fun setRunning(on: Boolean) {
        if (on) { if (!anim.isStarted) anim.start() } else anim.cancel()
    }

    override fun onDetachedFromWindow() { anim.cancel(); super.onDetachedFromWindow() }

    override fun onDraw(c: Canvas) {
        p.color = color
        val n = 4
        val gap = width * 0.14f
        val bw = (width - gap * (n - 1)) / n
        for (i in 0 until n) {
            val k = 0.5f + 0.5f * sin(t * (1f + i * 0.35f) + i * 1.7f)
            val h = height * (0.3f + 0.7f * k)
            val x = i * (bw + gap)
            c.drawRoundRect(x, (height - h) / 2f, x + bw, (height + h) / 2f, bw / 2f, bw / 2f, p)
        }
    }
}

class IslandView(ctx: Context) : FrameLayout(ctx) {
    enum class Mode { HIDDEN, COMPACT, EXPANDED }

    var onTap: (() -> Unit)? = null
    var onLongPress: (() -> Unit)? = null
    var onDismiss: (() -> Unit)? = null

    private val dp = ctx.resources.displayMetrics.density
    private val Int.px: Int get() = (this * dp).toInt()
    private val d: Int get() = Prefs.d(context).px

    private val bg = GradientDrawable().apply { setColor(Color.BLACK) }
    private val spacer = View(ctx)
    private val icon = ImageView(ctx)
    private val title = TextView(ctx)
    private val text = TextView(ctx)
    private val compact = TextView(ctx)
    private val eq = EqView(ctx)
    private val ring = RingView(ctx)
    private val col = LinearLayout(ctx)
    private val topRow = LinearLayout(ctx)
    private val actions = LinearLayout(ctx)
    private val root = LinearLayout(ctx)
    private var anim: ValueAnimator? = null
    private var curW = 0f
    private var curH = 0f
    var mode = Mode.HIDDEN
        private set

    private val gestures = GestureDetector(ctx, object : GestureDetector.SimpleOnGestureListener() {
        override fun onDown(e: MotionEvent): Boolean = true
        override fun onSingleTapUp(e: MotionEvent): Boolean { onTap?.invoke(); return true }
        override fun onLongPress(e: MotionEvent) { onLongPress?.invoke() }
        override fun onFling(a: MotionEvent?, b: MotionEvent, vx: Float, vy: Float): Boolean {
            if ((vy < -800f && abs(vy) > abs(vx)) || (vx < -800f && abs(vx) > abs(vy))) {
                onDismiss?.invoke(); return true
            }
            return false
        }
    })

    init {
        background = bg
        alpha = 0f
        visibility = View.INVISIBLE

        icon.outlineProvider = object : ViewOutlineProvider() {
            override fun getOutline(v: View, o: Outline) { o.setRoundRect(0, 0, v.width, v.height, 6 * dp) }
        }
        icon.clipToOutline = true
        title.setTextColor(Color.WHITE); title.textSize = 13f; title.maxLines = 1
        title.setTypeface(title.typeface, Typeface.BOLD); title.ellipsize = TextUtils.TruncateAt.END
        text.setTextColor(0xFFBBBBBB.toInt()); text.textSize = 12f; text.maxLines = 1
        text.ellipsize = TextUtils.TruncateAt.END
        compact.setTextColor(Color.WHITE); compact.textSize = 12f; compact.maxLines = 1
        compact.setTypeface(compact.typeface, Typeface.BOLD)

        col.orientation = LinearLayout.VERTICAL
        col.addView(title); col.addView(text)

        topRow.orientation = LinearLayout.HORIZONTAL
        topRow.gravity = Gravity.CENTER_VERTICAL
        topRow.addView(spacer, LinearLayout.LayoutParams(d, 1))
        topRow.addView(icon, LinearLayout.LayoutParams(28.px, 28.px).apply { rightMargin = 10.px })
        topRow.addView(col, LinearLayout.LayoutParams(0, WRAP, 1f))
        topRow.addView(compact, LinearLayout.LayoutParams(WRAP, WRAP).apply { rightMargin = 14.px })
        topRow.addView(eq, LinearLayout.LayoutParams(26.px, 16.px).apply { rightMargin = 14.px })

        actions.orientation = LinearLayout.HORIZONTAL
        actions.gravity = Gravity.CENTER
        actions.visibility = View.GONE

        root.orientation = LinearLayout.VERTICAL
        root.addView(topRow, LinearLayout.LayoutParams(MATCH, 0, 1f))
        root.addView(actions, LinearLayout.LayoutParams(MATCH, WRAP).apply { setMargins(12.px, 0, 12.px, 8.px) })
        root.alpha = 0f

        addView(root, FrameLayout.LayoutParams(MATCH, MATCH))
        addView(ring, FrameLayout.LayoutParams(d, d, Gravity.START or Gravity.TOP))
        ring.visibility = View.GONE

        layoutParams = FrameLayout.LayoutParams(d, d)
        curW = d.toFloat(); curH = curW
        applySize(curW, curH)
    }

    override fun onTouchEvent(ev: MotionEvent): Boolean = gestures.onTouchEvent(ev) || super.onTouchEvent(ev)

    private fun applySize(w: Float, h: Float) {
        curW = w; curH = h
        bg.cornerRadius = minOf(h / 2f, 28.px.toFloat())
        val lp = layoutParams
        lp.width = w.toInt(); lp.height = h.toInt()
        layoutParams = lp
    }

    private fun animateTo(w: Float, h: Float, a: Float, rootAlpha: Float, spring: Boolean, end: (() -> Unit)? = null) {
        anim?.cancel()
        val w0 = curW; val h0 = curH; val r0 = root.alpha
        anim = ValueAnimator.ofFloat(0f, 1f).apply {
            duration = if (spring) 520L else 320L
            interpolator = if (spring) OvershootInterpolator(1.15f) else DecelerateInterpolator()
            addUpdateListener {
                val t = it.animatedValue as Float
                applySize(w0 + (w - w0) * t, h0 + (h - h0) * t)
                root.alpha = (r0 + (rootAlpha - r0) * it.animatedFraction).coerceIn(0f, 1f)
            }
            addListener(object : AnimatorListenerAdapter() {
                private var canceled = false
                override fun onAnimationCancel(an: Animator) { canceled = true }
                override fun onAnimationEnd(an: Animator) {
                    if (!canceled) { alpha = a; end?.invoke() }
                }
            })
            start()
        }
    }

    private fun bind(e: IslandEvent) {
        (spacer.layoutParams as LinearLayout.LayoutParams).width = d
        spacer.requestLayout()
        (ring.layoutParams as FrameLayout.LayoutParams).apply { width = d; height = d }
        ring.requestLayout()
        icon.visibility = if (e.icon == null) View.GONE else View.VISIBLE
        icon.setImageDrawable(e.icon)
        icon.scaleType = if (e.tintIcon) ImageView.ScaleType.FIT_CENTER else ImageView.ScaleType.CENTER_CROP
        if (e.tintIcon) icon.setColorFilter(e.accent) else icon.clearColorFilter()
        title.text = e.title
        text.text = e.text
        eq.color = e.accent
        if (e.progress >= 0f) {
            ring.visibility = View.VISIBLE
            ring.color = e.accent
            ring.progress = e.progress
        } else {
            ring.visibility = View.GONE
        }
    }

    fun showExpanded(e: IslandEvent, screenW: Int) {
        bind(e)
        compact.visibility = View.GONE
        eq.visibility = View.GONE; eq.setRunning(false)
        col.visibility = View.VISIBLE
        title.visibility = View.VISIBLE
        text.visibility = if (e.text.isEmpty()) View.GONE else View.VISIBLE
        actions.removeAllViews()
        e.actions.forEach { act ->
            val b = TextView(context)
            b.text = act.label
            b.setTextColor(Color.WHITE)
            b.textSize = 14f
            b.gravity = Gravity.CENTER
            b.background = GradientDrawable().apply { setColor(0xFF2A2A2A.toInt()); cornerRadius = 20 * dp }
            b.setOnClickListener { act.run() }
            actions.addView(b, LinearLayout.LayoutParams(0, 36.px, 1f).apply { setMargins(4.px, 0, 4.px, 0) })
        }
        actions.visibility = if (e.actions.isEmpty()) View.GONE else View.VISIBLE
        val h = (if (e.actions.isEmpty()) 56 else 100).px.toFloat()
        mode = Mode.EXPANDED
        visibility = View.VISIBLE
        alpha = 1f
        performHapticFeedback(HapticFeedbackConstants.CLOCK_TICK)
        animateTo(minOf(300.px, screenW - 24.px).toFloat(), h, 1f, 1f, spring = true)
    }

    fun showCompact(e: IslandEvent) {
        bind(e)
        actions.removeAllViews(); actions.visibility = View.GONE
        col.visibility = View.GONE
        val media = e.kind == Kind.MEDIA
        eq.visibility = if (media) View.VISIBLE else View.GONE
        eq.setRunning(media)
        compact.visibility = if (media) View.GONE else View.VISIBLE
        compact.text = e.compactText
        mode = Mode.COMPACT
        visibility = View.VISIBLE
        alpha = 1f
        val extra = if (media) 30.px else if (e.compactText.isEmpty()) 8.px else 62.px
        val iconW = if (e.icon == null) 0 else 38.px
        animateTo((d + iconW + extra + 10.px).toFloat(), d.toFloat(), 1f, 1f, spring = true)
    }

    fun updateCompact(t: String, progress: Float) {
        compact.text = t
        if (ring.visibility == View.VISIBLE && progress >= 0f) ring.progress = progress
    }

    fun hide() {
        mode = Mode.HIDDEN
        eq.setRunning(false)
        animateTo(d.toFloat(), d.toFloat(), 0f, 0f, spring = false) { visibility = View.INVISIBLE }
    }
}
