package com.example.island

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.text.InputType
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Switch
import android.widget.TextView
import androidx.core.app.NotificationManagerCompat

class MainActivity : Activity() {
    private lateinit var stAcc: TextView
    private lateinit var stNot: TextView

    private fun px(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun header(root: LinearLayout, t: String) {
        root.addView(TextView(this).apply {
            text = t; setTextColor(0xFF8E8E93.toInt()); textSize = 13f
            setPadding(0, px(24), 0, px(2))
        })
    }

    private fun button(root: LinearLayout, label: String, accent: Boolean = false, action: () -> Unit) {
        val b = Button(this)
        b.text = label
        b.isAllCaps = false
        b.setTextColor(Color.WHITE)
        b.textSize = 15f
        b.background = GradientDrawable().apply {
            setColor(if (accent) 0xFF0A84FF.toInt() else 0xFF1C1C1E.toInt())
            cornerRadius = px(14).toFloat()
        }
        b.setOnClickListener { action() }
        root.addView(b, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, px(52)).apply { topMargin = px(8) })
    }

    private fun toggle(root: LinearLayout, label: String, key: String) {
        val s = Switch(this)
        s.text = label
        s.setTextColor(Color.WHITE)
        s.isChecked = Prefs.on(this, key)
        s.setPadding(0, px(10), 0, px(10))
        s.setOnCheckedChangeListener { _, v -> Prefs.setOn(this, key, v) }
        root.addView(s)
    }

    private fun slider(root: LinearLayout, label: String, key: String, maxV: Int, cur: Int) {
        val tv = TextView(this)
        tv.text = "$label: $cur dp"
        tv.setTextColor(Color.WHITE)
        root.addView(tv)
        val sb = SeekBar(this)
        sb.max = maxV
        sb.progress = cur
        sb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                tv.text = "$label: $p dp"
                if (fromUser) {
                    Prefs.set(this@MainActivity, key, p)
                    Prefs.setOn(this@MainActivity, "auto", false)
                }
            }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {
                IslandBus.post(IslandEvent(title = "Калибровка", text = "Левый край = камера"))
            }
        })
        root.addView(sb, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        window.statusBarColor = Color.BLACK
        window.navigationBarColor = Color.BLACK
        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setPadding(px(20), px(44), px(20), px(28))
        root.setBackgroundColor(Color.BLACK)

        val h1 = TextView(this)
        h1.text = "Dynamic Island"
        h1.setTextColor(Color.WHITE)
        h1.textSize = 30f
        h1.setTypeface(h1.typeface, Typeface.BOLD)
        root.addView(h1)
        val h2 = TextView(this)
        h2.text = "Остров вокруг фронтальной камеры"
        h2.setTextColor(0xFF8E8E93.toInt())
        h2.textSize = 14f
        root.addView(h2)

        stAcc = TextView(this); stAcc.textSize = 15f; stAcc.setPadding(0, px(20), 0, 0)
        stNot = TextView(this); stNot.textSize = 15f; stNot.setPadding(0, px(4), 0, 0)
        root.addView(stAcc); root.addView(stNot)

        header(root, "НАСТРОЙКА")
        button(root, "1. Включить службу «Dynamic Island»", accent = true) {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }
        button(root, "2. Дать доступ к уведомлениям") {
            startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
        }
        button(root, "Определить камеру автоматически") {
            IslandBus.onRecalibrate?.invoke()
            Handler(Looper.getMainLooper()).postDelayed({ recreate() }, 900)
        }

        header(root, "ПОКАЗАТЬ ДЕМО")
        button(root, "Уведомление") {
            IslandBus.post(IslandEvent(icon = getDrawable(android.R.drawable.ic_dialog_info),
                title = "Dynamic Island", text = "Всё работает"))
        }
        button(root, "Входящий звонок") {
            IslandBus.post(IslandEvent(Kind.CALL, getDrawable(android.R.drawable.ic_menu_call),
                "Входящий звонок", "Мама", sticky = true, accent = 0xFF30D158.toInt(), key = "test",
                actions = listOf(IslandAction("Отклонить") { IslandBus.removed("test") },
                                 IslandAction("Ответить") { IslandBus.removed("test") })))
        }
        button(root, "Зарядка") {
            IslandBus.post(IslandEvent(Kind.CHARGING, getDrawable(android.R.drawable.ic_lock_idle_charging),
                "Зарядка", "78%", accent = 0xFF30D158.toInt(), progress = 0.78f))
        }
        button(root, "Музыка") {
            val e = IslandEvent(Kind.MEDIA, getDrawable(android.R.drawable.ic_media_play),
                "Blinding Lights", "The Weeknd", accent = 0xFFFF2D55.toInt(), key = "media",
                actions = listOf(IslandAction("⏮") {}, IslandAction("⏸") {}, IslandAction("⏭") {}))
            IslandBus.live(Kind.MEDIA, e)
            IslandBus.post(e)
        }
        button(root, "Режим «Без звука»") {
            IslandBus.post(IslandEvent(icon = getDrawable(android.R.drawable.ic_lock_silent_mode),
                title = "Без звука", accent = 0xFFFF453A.toInt()))
        }
        button(root, "Сбросить демо") {
            IslandBus.live(Kind.MEDIA, null)
            IslandBus.onStopTimer?.invoke()
        }

        header(root, "ТАЙМЕР")
        val min = EditText(this)
        min.hint = "Минуты"
        min.setTextColor(Color.WHITE)
        min.setHintTextColor(0xFF8E8E93.toInt())
        min.inputType = InputType.TYPE_CLASS_NUMBER
        root.addView(min)
        button(root, "Запустить таймер") {
            val m = min.text.toString().toIntOrNull() ?: 1
            IslandBus.onStartTimer?.invoke(m * 60)
        }
        button(root, "Остановить таймер") { IslandBus.onStopTimer?.invoke() }

        header(root, "ЧТО ПОКАЗЫВАТЬ")
        toggle(root, "Уведомления и звонки", "notif")
        toggle(root, "Зарядка и низкий заряд", "charge")
        toggle(root, "Режим звука", "ringer")

        header(root, "ПОЛОЖЕНИЕ (ручная подстройка)")
        slider(root, "Отступ слева (X)", "x", 120, Prefs.x(this))
        slider(root, "Отступ сверху (Y)", "y", 80, Prefs.y(this))
        slider(root, "Диаметр вокруг камеры", "d", 60, Prefs.d(this))

        header(root, "ЖЕСТЫ")
        val tips = TextView(this)
        tips.text = "Тап по острову открывает приложение. Долгое нажатие раскрывает остров. " +
            "Свайп вверх или влево убирает. Остров прячется в горизонтальном режиме."
        tips.setTextColor(0xFFBBBBBB.toInt())
        root.addView(tips)

        val sv = ScrollView(this)
        sv.setBackgroundColor(Color.BLACK)
        sv.addView(root)
        setContentView(sv)
    }

    override fun onResume() {
        super.onResume()
        val acc = (Settings.Secure.getString(contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: "")
            .contains("$packageName/")
        val not = NotificationManagerCompat.getEnabledListenerPackages(this).contains(packageName)
        stAcc.text = if (acc) "● Остров включён" else "● Остров выключен: включи службу"
        stAcc.setTextColor(if (acc) 0xFF30D158.toInt() else 0xFFFF453A.toInt())
        stNot.text = if (not) "● Доступ к уведомлениям есть" else "● Нет доступа к уведомлениям"
        stNot.setTextColor(if (not) 0xFF30D158.toInt() else 0xFFFF453A.toInt())
    }
}
