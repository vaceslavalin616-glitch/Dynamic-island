package com.example.island

import android.content.ComponentName
import android.content.Context
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.drawable.BitmapDrawable
import android.media.MediaMetadata
import android.media.session.MediaController
import android.media.session.MediaSessionManager
import android.media.session.PlaybackState

/** Следит за активными медиасессиями (Spotify, YouTube Music и т.д.) через доступ к уведомлениям. */
class MediaWatcher(private val ctx: Context, private val component: ComponentName) {
    private val msm = ctx.getSystemService(Context.MEDIA_SESSION_SERVICE) as MediaSessionManager
    private val callbacks = mutableMapOf<MediaController, MediaController.Callback>()
    private var lastTrack = ""

    private val sessionsListener = MediaSessionManager.OnActiveSessionsChangedListener { attach(it) }

    fun start() {
        runCatching {
            msm.addOnActiveSessionsChangedListener(sessionsListener, component)
            attach(msm.getActiveSessions(component))
        }
    }

    fun stop() {
        runCatching { msm.removeOnActiveSessionsChangedListener(sessionsListener) }
        callbacks.forEach { (c, cb) -> c.unregisterCallback(cb) }
        callbacks.clear()
        IslandBus.live(Kind.MEDIA, null)
    }

    private fun attach(list: List<MediaController>?) {
        callbacks.forEach { (c, cb) -> c.unregisterCallback(cb) }
        callbacks.clear()
        list?.forEach { c ->
            val cb = object : MediaController.Callback() {
                override fun onPlaybackStateChanged(state: PlaybackState?) = update(c)
                override fun onMetadataChanged(metadata: MediaMetadata?) = update(c)
            }
            c.registerCallback(cb)
            callbacks[c] = cb
        }
        val main = list?.firstOrNull { it.playbackState?.state == PlaybackState.STATE_PLAYING } ?: list?.firstOrNull()
        if (main != null) update(main) else IslandBus.live(Kind.MEDIA, null)
    }

    /** Яркий оттенок обложки для эквалайзера и иконки. */
    private fun accentOf(bmp: Bitmap?): Int {
        if (bmp == null) return 0xFFFFFFFF.toInt()
        val px = Bitmap.createScaledBitmap(bmp, 1, 1, true).getPixel(0, 0)
        val hsv = FloatArray(3)
        Color.colorToHSV(px, hsv)
        if (hsv[1] < 0.15f) return 0xFFFFFFFF.toInt()
        hsv[1] = maxOf(hsv[1], 0.5f)
        hsv[2] = 1f
        return Color.HSVToColor(hsv)
    }

    private fun update(c: MediaController) {
        val playing = c.playbackState?.state == PlaybackState.STATE_PLAYING
        val md = c.metadata
        val title = md?.getString(MediaMetadata.METADATA_KEY_TITLE) ?: ""
        if (title.isEmpty()) { IslandBus.live(Kind.MEDIA, null); return }
        val artist = md?.getString(MediaMetadata.METADATA_KEY_ARTIST) ?: ""
        val bmp = md?.getBitmap(MediaMetadata.METADATA_KEY_ALBUM_ART) ?: md?.getBitmap(MediaMetadata.METADATA_KEY_ART)
        val icon = bmp?.let { BitmapDrawable(ctx.resources, it) } ?: ctx.getDrawable(android.R.drawable.ic_media_play)
        val tc = c.transportControls
        val acts = listOf(
            IslandAction("⏮") { tc.skipToPrevious() },
            IslandAction(if (playing) "⏸" else "▶") { if (playing) tc.pause() else tc.play() },
            IslandAction("⏭") { tc.skipToNext() }
        )
        val e = IslandEvent(Kind.MEDIA, icon, title, artist, intent = c.sessionActivity,
            actions = acts, tintIcon = bmp == null, accent = accentOf(bmp), key = "media")
        IslandBus.live(Kind.MEDIA, if (playing) e else null)
        if (playing && title != lastTrack) IslandBus.post(e)
        if (playing) lastTrack = title
    }
}
