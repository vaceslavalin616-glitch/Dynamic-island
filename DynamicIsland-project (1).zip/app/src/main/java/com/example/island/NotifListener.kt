package com.example.island

import android.app.Notification
import android.content.ComponentName
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification

class NotifListener : NotificationListenerService() {
    private var media: MediaWatcher? = null

    override fun onListenerConnected() {
        media = MediaWatcher(this, ComponentName(this, NotifListener::class.java)).also { it.start() }
    }

    override fun onListenerDisconnected() { media?.stop(); media = null }

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        if (!Prefs.on(this, "notif")) return
        val n = sbn.notification
        val isCall = n.category == Notification.CATEGORY_CALL
        if (n.flags and Notification.FLAG_GROUP_SUMMARY != 0) return
        if (!isCall && n.flags and Notification.FLAG_ONGOING_EVENT != 0) return
        if (n.category == Notification.CATEGORY_TRANSPORT) return
        if (sbn.packageName == packageName) return
        val ex = n.extras
        val title = ex.getCharSequence(Notification.EXTRA_TITLE)?.toString() ?: return
        val text = ex.getCharSequence(Notification.EXTRA_TEXT)?.toString() ?: ""
        val icon = runCatching { n.smallIcon?.loadDrawable(this) }.getOrNull()
        val acts: List<IslandAction> = if (isCall) {
            (n.actions?.take(2) ?: emptyList()).map { a ->
                IslandAction(a.title.toString()) { runCatching { a.actionIntent.send() } }
            }
        } else emptyList()
        IslandBus.post(IslandEvent(
            kind = if (isCall) Kind.CALL else Kind.NOTIFICATION,
            icon = icon, title = title, text = text, intent = n.contentIntent,
            actions = acts, sticky = isCall,
            accent = if (isCall) 0xFF30D158.toInt() else 0xFFFFFFFF.toInt(),
            key = sbn.key
        ))
    }

    override fun onNotificationRemoved(sbn: StatusBarNotification) { IslandBus.removed(sbn.key) }
}
