package com.example.island

import android.content.Context

object Prefs {
    private fun sp(c: Context) = c.getSharedPreferences("island", Context.MODE_PRIVATE)
    // Положение острова в dp. Обычно определяется автоматически по вырезу камеры.
    fun x(c: Context) = sp(c).getInt("x", 12)
    fun y(c: Context) = sp(c).getInt("y", 6)
    fun d(c: Context) = sp(c).getInt("d", 32)
    fun set(c: Context, k: String, v: Int) = sp(c).edit().putInt(k, v).apply()
    fun on(c: Context, k: String, def: Boolean = true) = sp(c).getBoolean(k, def)
    fun setOn(c: Context, k: String, v: Boolean) = sp(c).edit().putBoolean(k, v).apply()
}
